import {Component, OnInit} from '@angular/core';

export enum COMPONENT_TYPE {
  ALERT = 'alert',
  BUTTON = 'button',
}


@Component({
  selector: 'app-virtual-page',
  templateUrl: './virtual-page.component.html',
  styleUrls: ['./virtual-page.component.scss']
})
export class VirtualPageComponent implements OnInit {

  readonly component_type = COMPONENT_TYPE;

  components = [
    {type: COMPONENT_TYPE.ALERT},
    {type: COMPONENT_TYPE.BUTTON},
    {type: COMPONENT_TYPE.BUTTON},
    {type: COMPONENT_TYPE.BUTTON},
    {type: COMPONENT_TYPE.BUTTON},
    {type: COMPONENT_TYPE.BUTTON},
  ]

  constructor() {
  }

  ngOnInit(): void {
  }

}
